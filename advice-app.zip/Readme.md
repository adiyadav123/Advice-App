# Advice App

<br>
<br>

> Welcome to the Random Advice Web App! This simple web application provides users with random pieces of advice to inspire, motivate, or entertain them. Whether you're looking for a quick pick-me-up or some words of wisdom, this app has got you covered.

> It's free so you can use it.


<br>
<br>

# Preview

<img src="./preview.png" height="auto" width="auto">